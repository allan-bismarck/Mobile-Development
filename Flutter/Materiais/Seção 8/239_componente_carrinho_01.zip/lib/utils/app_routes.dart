class AppRoutes {
  static const PRODUCT_DETAIL = '/product-detail';
  static const CART = '/cart';
}
