class AppRoutes {
  static const PRODUCT_DETAIL = '/product-detail';
}
